import sys, random


LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def main():
    print('###############################################################################################')
    print('#/                                                                                           \\#')
    print("#/                                   Encryptor/Decryptor Tool!                               \\#")
    print('#/                                 Creator: Abed al Rahman Sidani                            \\#')
    print('#/                                                                                           \\#') 
    print('###############################################################################################')
    print()
    myMessage = input("Enter your Secret Message: \n ->")
    myKey = 'FLWOAYUISVKMNXPBDCRJTQEGHZ'
    print()
    myMode = input("Would you like to Encrypt(e), or Decrypt(d): ")

    checkValidKey(myKey)

    if myMode == 'e':
        translated = encryptMessage(myKey, myMessage )
    elif myMode == 'd':
        translated = decryptMessage(myKey, myMessage)

    print('\n\nUsing key %s' % (myKey),'\n\n')
    if myMode == 'd':

        print('\nThe Decrypted message is: ->', translated)
    else:
        print("\nThe Encrypted Message is: -> ", translated)

    print()

def checkValidKey(key):
    keyList = list(key)
    lettersList = list(LETTERS)
    keyList.sort()
    lettersList.sort()

    if keyList != lettersList:
        sys.exit('There is an error in the key or symbol set.')


def encryptMessage(key, message):
    return translateMessage(key, message, 'e')

def decryptMessage(key, message):
    return translateMessage(key, message, 'd')

def translateMessage(key, message, mode):
    translated = ''
    charsA = LETTERS
    charsB = key

    if mode == 'd':
        charsA, charsB = charsB, charsA

    for symbol in message:
        if symbol.upper() in charsA:
            symIndex = charsA.find(symbol.upper())
            if symbol.isupper():
                translated += charsB[symIndex].upper()
            else:
                translated += charsB[symIndex].lower()
        else:
            translated += symbol
    return translated

def getRandomKey():
    key = list(LETTERS)
    random.shuffle(key)
    return ''.join(key)

if __name__ == '__main__':
    main()
